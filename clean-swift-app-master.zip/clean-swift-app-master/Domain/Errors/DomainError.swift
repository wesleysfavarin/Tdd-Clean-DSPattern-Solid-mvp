import Foundation

public enum DomainError: Error {
    case unexpected
    case emailInUse
    case expiredSession
}
