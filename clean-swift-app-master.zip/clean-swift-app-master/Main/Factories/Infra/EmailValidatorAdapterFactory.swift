import Foundation
import Infra

func makeAlamofireAdapter() -> AlamofireAdapter {
    return AlamofireAdapter()
}
