import Foundation
import Infra

func makeEmailValidatorAdapter() -> EmailValidatorAdapter {
    return EmailValidatorAdapter()
}
